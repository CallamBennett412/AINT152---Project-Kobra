﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleShooting : MonoBehaviour
{

    public GameObject bulletPrefab;
    public float attackSpeed = 0.5f;
    public float coolDown;
    public float bulletSpeed = 500;
    public float yValue = 1f; // Used to make it look like it's shot from the gun itself (offset)
    public float xValue = 0.2f; // Same as above
    public Transform bulletSpawn;

    private bool isFiring = false;

    void SetFiring()
    {
        isFiring = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time >= coolDown)
        {
            if (Input.GetMouseButton(0))
            {
                Fire();
            }
        }
    }


    void Fire()
    {
        isFiring = true;
        GameObject LaserPrefab = Instantiate(bulletPrefab, bulletSpawn.position, bulletSpawn.rotation);

        LaserPrefab.GetComponent<Rigidbody2D>().AddForce(transform.up * bulletSpeed);

        Invoke("SetFiring", coolDown);

        coolDown = Time.time + attackSpeed;
    }
}
