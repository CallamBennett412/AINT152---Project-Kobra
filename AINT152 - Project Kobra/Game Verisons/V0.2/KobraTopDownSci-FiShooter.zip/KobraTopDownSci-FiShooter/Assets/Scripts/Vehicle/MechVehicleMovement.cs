﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechVehicleMovement: MonoBehaviour {
	public float speed = 5.0f;
	Rigidbody2D rigidbody2D;
	Animator anim;
    public Camera theCamera;
    public float smoothing = 5.0f;
    public float adjustmentAngle = 0.0f;

    public bool playerInMech = false;

    public Transform player;

    public VehicleShooting[] gunz;

	void Start () {

		rigidbody2D = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator> ();

        for (int i = 0; i < gunz.Length; i++)
        {
            gunz[i].enabled = false;
        }
	}

	void Update()
	{
        
        
        if (Input.GetKey (KeyCode.W)) {
			anim.SetBool ("Moving", true);
		} else if (Input.GetKey (KeyCode.A)) {
			anim.SetBool ("Moving", true);
		} else if (Input.GetKey (KeyCode.S)) {
			anim.SetBool ("Moving", true);
		} else if (Input.GetKey (KeyCode.D)) {
			anim.SetBool ("Moving", true);
		} else {
			anim.SetBool ("Moving", false);
		}
        

        if (Input.GetKeyDown(KeyCode.E))
        {
            //GetComponent<Collider2D>().enabled = false;
            print("!");
            player.gameObject.SetActive(true);
            player.parent = transform.parent;
            player.position = new Vector3(transform.position.x, transform.position.y + 1, transform.position.z);
            playerInMech = false;


            for (int i = 0; i < gunz.Length; i++)
            {
                gunz[i].enabled = false;
            }

        }

        if (playerInMech == true)
        {
            Vector3 target = theCamera.ScreenToWorldPoint(Input.mousePosition);
            Vector3 difference = target - transform.position;

            difference.Normalize();

            float rotZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
            Quaternion newRotation = Quaternion.Euler(new Vector3(0.0f, 0.0f, rotZ + adjustmentAngle));
            transform.rotation = Quaternion.Lerp(transform.rotation, newRotation, Time.deltaTime * smoothing);

        }
    }

	void FixedUpdate () {
        if (playerInMech)
        {
            float x = Input.GetAxis("Horizontal");
            float y = Input.GetAxis("Vertical");

            rigidbody2D.velocity = new Vector2(x, y) * speed;
        }
            rigidbody2D.angularVelocity = 0.0f;
        
		
	}


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            player = collision.transform;
            player.parent = transform;
            player.position = transform.position;
            player.gameObject.SetActive(false);
            playerInMech = true;

            for (int i = 0; i < gunz.Length; i++)
            {
                gunz[i].enabled = true;
            }
        }
    }
}