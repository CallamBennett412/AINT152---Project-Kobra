﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour {
	public float speed;
    public float destroyTime = 0.7f;

	void Start ()
	{
		
        Invoke("Die", destroyTime);
	}

    void Die()
    {
        Destroy(gameObject);       
    }

    private void OnDestroy()
    {
        CancelInvoke("Die");
    }

    private void FixedUpdate()
    {
       GetComponent<Rigidbody>().velocity = transform.up * speed;
    }
}
